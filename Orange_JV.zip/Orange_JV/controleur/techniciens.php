
<?php
if(isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
echo "<br>";
echo "<h2> Gestion des techniciens </h2>";
}
?>

<?php
if(isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
$leTechnicien = null;
if (isset($_GET['action']) && isset($_GET['idtechnicien'])) {
	$action = $_GET['action'];
	$idtechnicien = $_GET['idtechnicien'];

	switch ($action) {
		case "sup":
			$unControleur->deleteTechnicien($idtechnicien);
			break;
		case "edit":
			$leTechnicien = $unControleur->selectWhereTechnicien($idtechnicien);
			break;
	}
}



require_once("vue/vue_insert_technicien.php");
if (isset($_POST['Valider'])) {
	$unControleur->insertTechnicien($_POST);
	echo "<br> Insertion réussie du technicien.";
}


if (isset($_POST['Modifier'])) {
	$unControleur->updateTechnicien($_POST);

	//header("Location: index.php?page=2");
}
}

if (isset($_POST["Filtrer"])) {
	$filtre = $_POST['filtre'];
	$lesTechniciens = $unControleur->selectLikeTechnicien($filtre);
} else {
	$lesTechniciens = $unControleur->selectAllTechnicien();
}



require_once("vue/vue_select_techniciens.php");


?>
<br>
<br>