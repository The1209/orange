<link rel="stylesheet" href="assets/css/footer.css">
<footer>
    <div>
        <p>Orange SA</p>
        <p>Adresse : 78 rue Olivier de Serres, 75015 Paris, France</p>
        <p>
            Téléphone : <a href="tel:+33123456789">+33 1 23 45 67 89</a>
        </p>
        <p>
            Email : <a href="mailto:contact@orange.com">contact@orange.com</a>
        </p>
    </div>
</footer>