<?php
require_once("modele/modele.class.php");
class Controleur
{
    private $unModele;

    public function __construct()
    {
        //instanciation du du modele
        $this->unModele = new Modele();

    }

    public function insertClient($tab)
    {
        //controler les donnes du client avant insertion
        //appel du modele pour l'insertion du client
        $this->unModele->insertClient($tab);
    }
    public function selectAllClients()
    {
        $lesClients = $this->unModele->selectAllClients();

        return $lesClients;
    }

    public function deleteClient($idclient)
    {

        $this->unModele->deleteClient($idclient);

    }
    public function selectWhereClient($idclient)
    {

        $unClient = $this->unModele->selectWhereClient($idclient);

        return $unClient;

    }
    public function updateClient($tab)
    {

        $this->unModele->updateClient($tab);

    }

    public function countClients()
    {

        return $this->unModele->countClients();
    }


    public function selectLikeClients($filtre)
    {

        $lesClients = $this->unModele->selectLikeClients($filtre);
        return $lesClients;
    }

    //*******************technicien***************** */
    public function insertTechnicien($tab)
    {
        //controler les donnes du client avant insertion
        //appel du modele pour l'insertion du client
        $this->unModele->insertTechnicien($tab);
    }
    public function selectAllTechnicien()
    {
        $lesTechiciens= $this->unModele->selectAllTechnicien();

        return $lesTechiciens;
    }

    public function deleteTechnicien($idtechnicien)
    {

        $this->unModele->deleteTechnicien($idtechnicien);

    }
    public function selectWhereTechnicien($idtechnicien)
    {

        $unClient = $this->unModele->selectWhereTechnicien($idtechnicien);

        return $unClient;

    }
    public function updateTechnicien($tab)
    {

        $this->unModele->updateTechnicien($tab);

    }

    public function countTechnicien()
    {

        return $this->unModele->countTechnicien();
    }


    public function selectLikeTechnicien($filtre)
    {

        $lesTechniciens = $this->unModele->selectLikeTechnicien($filtre);
        return $lesTechniciens;
    }
    /**************gestion USER***************/

    public function VerifConnexion($email, $mdp)
    {
        $unUser = $this->unModele->VerifConnexion($email, $mdp);
        return $unUser;

    }
    //*******************telephone***************** */
    public function insertTelephone($tab)
    {
        //controler les donnes du client avant insertion
        //appel du modele pour l'insertion du client
        $this->unModele->insertTelephone($tab);
    }
    public function selectAllTelephones()
    {
        $lesTelephones = $this->unModele->selectAllTelephones();

        return $lesTelephones;
    }

    public function deleteTelephone($idTelephone)
    {

        $this->unModele->deleteTelephone($idTelephone);

    }
    public function selectWhereTelephone($idTelephone)
    {

        $unClient = $this->unModele->selectWhereTelephone($idTelephone);

        return $unClient;

    }
    public function updateTelephone($tab)
    {

        $this->unModele->updateTelephone($tab);

    }

    public function countTelephones()
    {

        return $this->unModele->countTelephones();
    }


    public function selectLikeTelephones($filtre)
    {

        $lesTelephones = $this->unModele->selectLikeTelephones($filtre);
        return $lesTelephones;
    }

    /************************** intervention ****************** */
    public function insertIntervention($tab)
    {
        //controler les donnes du client avant insertion
        //appel du modele pour l'insertion du client
        $this->unModele->insertIntervention($tab);
    }
    public function selectAllInterventions()
    {
        $lesInterventions = $this->unModele->selectAllInterventions();

        return $lesInterventions;
    }

    public function deleteIntervention($idInterventions)
    {

        $this->unModele->deleteIntervention($idInterventions);

    }
    public function selectWhereIntervention($idInterventions)
    {

        $idInterventions = $this->unModele->selectWhereIntervention($idInterventions);

        return $idInterventions;

    }
    public function updateIntervention($tab)
    {

        $this->unModele->updateIntervention($tab);

    }

    public function countInterventions()
    {

        return $this->unModele->countInterventions();
    }


    public function selectLikeInterventions($filtre)
    {

        $idInterventions = $this->unModele->selectLikeInterventions($filtre);
        return $idInterventions;
    }

}


