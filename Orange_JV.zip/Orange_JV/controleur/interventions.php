<br> 
<?php if (isset($_SESSION['role']) && $_SESSION['role'] == "admin")
"<h2> Gestion des interventions </h2>"
?>
<?php
	require_once ("vue/vue_insert_intervention.php"); 
	
	require_once ("vue/vue_select_interventions.php"); 

?>
<br>
<br>