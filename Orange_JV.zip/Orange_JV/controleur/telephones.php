<br>
<h2> Gestion des techniciens </h2>

<?php
$leTelephone = null;
if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
if (isset($_GET['action']) && isset($_GET['idtelephone'])) {
	$action = $_GET['action'];
	$idtelephone = $_GET['idtelephone'];

	switch ($action) {
		case "sup":
			$unControleur->deleteTelephone($idtelephone);
			break;
		case "edit":
			$leTelephone = $unControleur->selectWhereTelephone($idtelephone);
			break;
	}
}


require_once("vue/vue_insert_telephone.php");
if (isset($_POST['Valider'])) {
	$unControleur->insertTelephone($_POST);
	echo "<br> Insertion réussie du telephone.";
}


if (isset($_POST['Modifier'])) {
	$unControleur->updateTelephone(($_POST));

	header("Location: index.php?page=4");
}
}


if (isset($_POST["Filtrer"])) {
	$filtre = $_POST['filtre'];
	$lesTelephones = $unControleur->selectLikeTelephones($filtre);
} else {
	$lesTelephones = $unControleur->selectAllTelephones();
}


require_once("vue/vue_select_telephones.php");


?>
<br>
<br>