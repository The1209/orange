<br> 
<h2> Bienvenue chez votre partenaire téléphonique Orange  </h2>
<h3>vous etes connectes: <?= $_SESSION['nom'] ?> avec le profil <?=$_SESSION['role']?></h3>
<img src="images/orange.png" height="400" width="600">
<br> <br>
<a href="https://www.orange.fr/portail"> Veuillez nous joindre sur notre site officiel </a> 
<br>
<br> 
