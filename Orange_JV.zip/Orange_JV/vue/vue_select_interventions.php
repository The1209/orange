<br>
<h2> Liste des interventions </h2>
<table border="1">
	<tr>
		<td> Id intervention </td>
		<td> Description </td>
		<td> Prix Intervention </td>
		<td> Date </td>
		<td> Technicien </td>
		<td> Téléphone </td>
		<?php 
		if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
		echo "<td> Opérations </td>";
		}
		?>
	</tr>

	<?php

	?> 
</table>


<link rel="stylesheet" href="assets/css/index.css">