<style>
form{
	background-color: #008000;
}
</style>
<br>
<h2> Ajout d'une intervention </h2>
<form method="post">
	<table>
		<tr>
			<td> Description </td>
			<td> <textarea name="description" rows="5" cols="60"> </textarea></td>
		</tr>
		<tr>
			<td> Prix Intervention </td>
			<td> <input type="text" name="prixInter"></td>
		</tr>
		<tr>
			<td> Date Intervention </td>
			<td> <input type="date" name="dateInter"></td>
		</tr>
		<tr>
			<td> Le Technicien </td>
			<td> 
					<select name="idtechnicien">
						<option value="xx"> xx </option>
					</select>
			</td>
		</tr>
		<tr>
			<td> Le Téléphone </td>
			<td>  
				<select name="idtelephone">
					<option value="xx">xx</option>
				</select>
			</td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" name="Valider" value="Valider"></td>
		</tr>
	</table>
	<?= ($leTechnicien == null) ? '' : '<input type="hidden" name="idtechnicien" value="' . $leTechnicien['idtechnicien'] . '">' ?>
</form>