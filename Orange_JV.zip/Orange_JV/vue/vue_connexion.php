<h3>Connexion au site orange</h3>
<img src="images/logo.png" height="100" width="100">
<br>
<br>
<form method="post">
    Email <br>
    <input type="text" name="email"> <br>
    MDP<br>
    <input type="password" name="mdp"><br>
    <input type="submit" name="Connexion" value="Connexion">
</form>