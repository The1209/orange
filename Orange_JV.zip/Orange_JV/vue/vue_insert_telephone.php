<?php
$lesClients = $unControleur->selectAllClients();
?>


<br>
<h2> Ajout d'un téléphone </h2>
<form method="post">
	<table>
		<tr>
			<td> Désignation </td>
			<td>
				<input type="text" name="designation"
					value="<?= ($leTelephone == null) ? '' : $leTelephone['designation'] ?>">
			</td>
		</tr>
		<tr>
			<td> Prix Achat </td>
			<td>
				<input type="text" name="prixAchat"
					value="<?= ($leTelephone == null) ? '' : $leTelephone['prixAchat'] ?>">
			</td>
		</tr>
		<tr>
			<td> Etat </td>
			<td>
				<select name="etat">
					<option value="excellent"> Excellent </option>
					<option value="bien"> Bien </option>
					<option value="mauvais"> Mauvais </option>
					<option value="inconnu"> Inconnu </option>
				</select>

			</td>
		</tr>
		<tr>
			<td> Date Achat </td>
			<td> <input type="date" name="dateAchat"
					value="<?= ($leTelephone == null) ? '' : $leTelephone['dateAchat'] ?>"></td>
		</tr>

		<tr>
			<td> Le client </td>
			<td>
				<select name="idclient">
					<?php
					foreach ($lesClients as $unClient) {
						echo '<option value="' . $unClient['idclient'] . '">';
						echo $unClient['nom'] . '   ' . $unClient['prenom'];
						echo "</option>";
					}
					?>

				</select>
			</td>
		</tr>

		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" <?= ($leTelephone == null) ? ' name="Valider" value="Valider" ' :
				' name="Modifier" value="Modifier"' ?>></td>
		</tr>
	</table>
	<?= ($leTelephone == null) ? '' : '<input type="hidden" name="idtelephone" value="' . $leTelephone['idtelephone'] . '">' ?>
</form>
</form>