
<br>
<h2> Ajout d'un technicien </h2>
<form method="post">
	<table class="bonjour">
		<tr>
			<td> Nom technicien </td>
			<td><input type="text" name="nom" value="<?= ($leTechnicien == null) ? '' : $leTechnicien['nom'] ?>"></td>
		</tr>
		<tr>
			<td> Prénom technicien </td>
			<td> <input type="text" name="prenom" value="<?= ($leTechnicien == null) ? '' : $leTechnicien['prenom'] ?>"></td>
		</tr>
		<tr>
			<td> Spécialité </td>
			<td> 
					<select name="specialite">
						<option value="telephonie"> Téléphonie </option>
						<option value="programmeur"> programmeur</option>
						<option value="TPE"> TPE</option>
						<option value="Autre"> Autre </option>
					</select>

			</td>
		</tr>
		<tr>
			<td> Email Contact </td>
			<td> <input type="text" name="email" value="<?= ($leTechnicien == null) ? '' : $leTechnicien['email'] ?>"></td>
		</tr>
		<tr>
			<td> Téléphone </td>
			<td> <input type="text" name="telephone" value="<?= ($leTechnicien == null) ? '' : $leTechnicien['telephone'] ?>"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" name="Valider" value="Valider"></td>
		</tr>
	</table>
	<?= ($leTechnicien == null) ? '' : '<input type="hidden" name="idtechnicien" value="' . $leTechnicien['idtechnicien'] . '">' ?>
</form>