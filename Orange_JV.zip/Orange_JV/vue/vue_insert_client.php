<br>
<h2> Ajout d'un client </h2>
<form method="post">


	<table class="table">
		<tr>
			<td> Nom Client </td>
			<td> <input type="text" name="nom" value="<?= ($leClient == null) ? '' : $leClient['nom'] ?>"></td>
		</tr>
		<tr>
			<td> Prénom Client </td>
			<td> <input type="text" name="prenom" value="<?= ($leClient == null) ? '' : $leClient['prenom'] ?>"></td>
		</tr>
		<tr>
			<td> Adresse courrier </td>
			<td> <input type="text" name="adresse" value="<?= ($leClient == null) ? '' : $leClient['adresse'] ?>"></td>
		</tr>
		<tr>
			<td> Email Contact </td>
			<td> <input type="text" name="email" value="<?= ($leClient == null) ? '' : $leClient['email'] ?>"></td>
		</tr>
		<tr>
			<td> Téléphone </td>
			<td> <input type="text" name="telephone" value="<?= ($leClient == null) ? '' : $leClient['tel'] ?>"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" <?= ($leClient == null) ? ' name="Valider" value="Valider" ' :
				' name="Modifier" value="Modifier"' ?>></td>
		</tr>
	</table>
	<?= ($leClient == null) ? '' : '<input type="hidden" name="idclient" value="' . $leClient['idclient'] . '">' ?>
</form>