<?php
$nbTelephones = $unControleur->countTelephones();
?>




<br>
<h2> Liste des Telephones(<?= $nbTelephones['nb'] ?>) </h2>
<form method="post">
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>
<table border="1">
	<tr>
		<td> Id téléphone </td>
		<td> Désignation </td>
		<td> Prix Achat </td>
		<td> Date Achat </td>
		<td> Etat </td>
		<td> Le Client </td>
		<?php 
		if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
		echo "<td> Opérations </td>";
		}
		?>
	</tr>


	<?php
	if (isset($lesTelephones))
		foreach ($lesTelephones as $unTelephone) {
			echo "<tr>";
			echo "<td>" . $unTelephone['idtelephone'] . "</td>";
			echo "<td>" . $unTelephone['designation'] . "</td>";
			echo "<td>" . $unTelephone['prixAchat'] . "</td>";
			echo "<td>" . $unTelephone['etat'] . "</td>";
			echo "<td>" . $unTelephone['dateAchat'] . "</td>";
			echo "<td>" . $unTelephone['prenom'] ." ".$unTelephone['nom']. "</td>";
			echo "<td>";
			if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
			echo "<a href='index.php?page=4&action=sup&idtechnicien=" . $unTelephone['idtelephone'] . "'>";
			echo "<img src='images/supprimer.jpeg' heigth='30' width='30'></a>";
			echo "<a href='index.php?page=4&action=edit&idtechnicien=" . $unTelephone['idtelephone'] . "'>";
			echo "<img src='images/editer.jpeg' heigth='30' width='30'></a>";
			echo "</td>";
			echo "</tr>";
			}


		}
	?>
</table>


<link rel="stylesheet" href="assets/css/index.css">