<?php
$nbClients = $unControleur->countClients();
?>




<br>
<h2> Liste des clients(<?= $nbClients['nb'] ?>) </h2>
<form method="post">
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>



<table border="1">
	<tr>
		<td> Id Client </td>
		<td> Nom </td>
		<td> Prénom </td>
		<td> Adresse courrier </td>
		<td> Email </td>
		<td> Téléphone </td>
		<?php 
		if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
		echo "<td> Opérations </td>";
		}
		?>
	</tr>

	<?php
	if (isset($lesClients)) {
		foreach ($lesClients as $unClient) {
			echo "<tr>";
			echo "<td>" . $unClient['idclient'] . "</td>";
			echo "<td>" . $unClient['nom'] . "</td>";
			echo "<td>" . $unClient['prenom'] . "</td>";
			echo "<td>" . $unClient['adresse'] . "</td>";
			echo "<td>" . $unClient['email'] . "</td>";
			echo "<td>" . $unClient['tel'] . "</td>";
			if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
			echo "<td>";
			echo "<a href='index.php?page=2&action=sup&idclient=" . $unClient['idclient'] . "'>";
			echo "<img src='images/supprimer.jpeg' heigth='30' width='30'></a>";
			echo "<a href='index.php?page=2&action=edit&idclient=" . $unClient['idclient'] . "'>";
			echo "<img src='images/editer.jpeg' heigth='30' width='30'></a>";
			echo "</td>";
			echo "</tr>";
			}


		}
	}

	?>
</table>

<link rel="stylesheet" href="assets/css/index.css">