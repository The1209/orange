<?php
$nbTechniciens = $unControleur->countTechnicien();
?>


<br>
<h2> Liste des Techniciens(<?= $nbTechniciens['nb'] ?>) </h2>
<form method="post">
	Filtrer par : <input type="text" name="filtre">
	<input type="submit" name="Filtrer" value="Filtrer">
</form>
<br>
<table border="1">
	<tr>
		<td> Id Technicien </td>
		<td> Nom </td>
		<td> Prénom </td>
		<td> Spécialité </td>
		<td> Email </td>
		<td> Téléphone </td>
		<?php 
		if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
		echo "<td> Opérations </td>";
		}
		?>
	</tr>

	<?php
if (!empty($lesTechniciens)) {
    foreach ($lesTechniciens as $unTechnicien) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($unTechnicien['idtechnicien']) . "</td>";
        echo "<td>" . htmlspecialchars($unTechnicien['nom']) . "</td>";
        echo "<td>" . htmlspecialchars($unTechnicien['prenom']) . "</td>";
        echo "<td>" . htmlspecialchars($unTechnicien['specialite']) . "</td>";
        echo "<td>" . htmlspecialchars($unTechnicien['email']) . "</td>";
        echo "<td>" . htmlspecialchars($unTechnicien['tel']) . "</td>";
        
        if (isset($_SESSION['role']) && $_SESSION['role'] == "admin"){
            echo "<td>";
            echo "<a href='index.php?page=3&action=sup&idtechnicien=" . $unTechnicien['idtechnicien'] . "'>";
            echo "<img src='images/supprimer.jpeg' height='30' width='30' alt='Supprimer'></a>";
            echo "<a href='index.php?page=3&action=edit&idtechnicien=" . $unTechnicien['idtechnicien'] . "'>";
            echo "<img src='images/editer.jpeg' height='30' width='30' alt='Editer'></a>";
            echo "</td>";
        }
        echo "</tr>";
    }
} 
?>

	
</table>


<link rel="stylesheet" href="assets/css/index.css">