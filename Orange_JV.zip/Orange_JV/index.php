<?php
session_start();
require_once("controleur/controleur.class.php");
$unControleur = new Controleur();
?>
<!DOCTYPE html>
<html>

<head>
	<title>SITE Orange</title>
	<meta charset="utf-8">
</head>

<body>
	<center>
		<h1> Site Orange </h1>
		<?php
		if (!isset($_SESSION['email'])) {
			require_once("vue/vue_connexion.php");
		}

		if (isset($_POST['Connexion'])) {
			$email = $_POST['email'];
			$mdp = $_POST['mdp'];
			$unUser = $unControleur->VerifConnexion($email, $mdp);
			//var_dump($unUser);
			if ($unUser) {
				$_SESSION['email'] = $unUser['email'];
				$_SESSION['nom'] = $unUser['nom'];
				$_SESSION['prenom'] = $unUser['prenom'];
				$_SESSION['role'] = $unUser['role'];
				header("location: index.php?page=1");

			} else {
				echo "<br> veuillez verifier vos identifant.";
			}
		}
		if (isset($_SESSION['email'])) {

			echo '
	<a href="index.php?page=1"> acceuil </a>
	<a href="index.php?page=2"> Clients </a>
	<a href="index.php?page=3"> Technicien </a>
	<a href="index.php?page=4"> Telephone </a>
	<a href="index.php?page=5"> Intervention </a>
	<a href="index.php?page=6"> Deconnexion </a>
	';
			if (isset($_GET['page'])) {
				$page = $_GET['page'];
			} else {
				$page = 1;
			}
			switch ($page) {
				case 1:
					require_once("controleur/home.php");
					break;
				case 2:
					require_once("controleur/clients.php");
					break;
				case 3:
					require_once("controleur/techniciens.php");
					break;
				case 4:
					require_once("controleur/telephones.php");
					break;
				case 5:
					require_once("controleur/interventions.php");
					break;
				case 6:
					session_destroy();
					unset($_SESSION['email']);
					header("Location: index.php");
					break;

			}
		}
		require("controleur/footeur.php");
		?>
	</center>
</body>

</html>