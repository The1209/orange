<?php
/*
   cette classe Modele permet l'interface avec la base de données. 
   L'ensemble des requetes sont exécutées ici. 
   Le controleur demande l'exécution d'une requete au Modele. Celui-ci lui repond en extraction des données ou injection des données dans les tables.
   */
class Modele
{
	private $unPdo; //PDO : PHP DATA Object c'est une classe PHP librairie qui permet la connexion sécurisée à la base de données.

	public function __construct()
	{
		try {
			$serveur = "localhost";
			$bdd = "orange_JV_2025";
			$user = "root";
			$mdp = "";
			//instanciation de la classe PDO 
			$this->unPdo = new PDO("mysql:host=" . $serveur . ";dbname=" . $bdd, $user, $mdp);
		} catch (PDOException $exp) {
			echo "Erreur de connexion à la base de données.";
			echo $exp->getMessage(); //message officiel de l'erreur
		}
	}
	/******************** Requetes Client ****************/
	public function insertClient($tab)
	{
		$requete = "insert into client values (null, :nom, :prenom, :adresse, :email, :telephone); ";
		$donnees = array(
			":nom" => $tab["nom"],
			":prenom" => $tab["prenom"],
			":adresse" => $tab["adresse"],
			":email" => $tab["email"],
			":telephone" => $tab["telephone"]
		);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
	}

	public function selectAllClients()
	{
		$requete = "select * from client ;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		//extraction des données avec la methode fetchAll
		return $exec->fetchAll();
	}

	public function selectWhereClient($idclient)
	{
		$requete = "select * from client where idclient = :idclient; ";
		$donnees = array(":idclient" => $idclient);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetch();

	}
	public function selectLikeClients($filtre)
	{
		$requete = "select * from client where nom like :filtre or prenom like :filtre or adresse like :filtre or email like :filtre or tel like :filtre;";
		$donnees = array(":filtre" => "%" . $filtre . "%");
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetchAll();
	}
	public function deleteClient($idclient)
	{
		$requete = "delete from client where idclient = :idclient ;";
		$donnees = array(":idclient" => $idclient);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);

	}

	public function updateClient($tab)
	{
		$requete = "update client set nom =:nom, prenom =:prenom, adresse=:adresse, email=:email, tel=:tel where idclient =:idclient; ";
		$donnees = array(
			":nom" => $tab["nom"],
			":prenom" => $tab["prenom"],
			":adresse" => $tab["adresse"],
			":email" => $tab["email"],
			":tel" => $tab["tel"],
			":idclient" => $tab["idclient"]
		);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);


	}
	public function countClients()
	{
		$requete = "select count(*) as nb from client;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		return $exec->fetch();
	}


	/******************** Requetes technicien ****************/
	public function insertTechnicien($tab)
{
    $requete = "insert into technicien values (null, :nom, :prenom, :specialite, :email, :telephone); ";
    $donnees = array(
        ":nom" => $tab["nom"],
        ":prenom" => $tab["prenom"],
        ":specialite" => $tab["specialite"],
        ":email" => $tab["email"],
        ":telephone" => $tab["telephone"]
    );
    $exec = $this->unPdo->prepare($requete);
    $exec->execute($donnees);
}



	public function selectAllTechnicien()
	{
		$requete = "select * from technicien ;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		//extraction des données avec la methode fetchAll
		return $exec->fetchAll();
	}

	public function selectWhereTechnicien($idtechnicien)
	{
		$requete = "select * from technicien where idtechnicien = :idtechnicien; ";
		$donnees = array(":idtechnicien" => $idtechnicien);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetch();

	}
	public function selectLikeTechnicien($filtre)
	{
		$requete = "select * from technicien where nom like :filtre or prenom like :filtre or specialite like :filtre or email like :filtre or tel like :filtre;";
		$donnees = array(":filtre" => "%" . $filtre . "%");
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetchAll();
	}
	public function deletetechnicien($idtechnicien)
	{
		$requete = "delete from technicien where idtechnicien = :idtechnicien ;";
		$donnees = array(":idtechnicien" => $idtechnicien);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);

	}

	public function updatetechnicien($tab)
{
    $requete = "update technicien set nom = :nom, prenom = :prenom, specialite = :specialite, email = :email, telephone = :telephone where idtechnicien = :idtechnicien; ";
    $donnees = array(
        ":nom" => $tab["nom"],
        ":prenom" => $tab["prenom"],
        ":specialite" => $tab["specialite"],
        ":email" => $tab["email"],
        ":telephone" => $tab["telephone"],
        ":idtechnicien" => $tab["idtechnicien"]
    );
    $exec = $this->unPdo->prepare($requete);
    $exec->execute($donnees);
}
	public function countTechnicien()
	{
		$requete = "select count(*) as nb from technicien;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		return $exec->fetch();
	}
	/********************requete telephone************* */
	public function insertTelephone($tab)
	{
		$requete = "insert into telephone values (null, :designation, :prixAchat, :etat, :dateAchat, :idclient); ";
		$donnees = array(
			":designation" => $tab["designation"],
			":prixAchat" => $tab["prixAchat"],
			":etat" => $tab["etat"],
			":dateAchat" => $tab["dateAchat"],
			":idclient" => $tab["idclient"]
		);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
	}

	public function selectAllTelephones()
	{
		$requete = "select t.*, c.nom, c.prenom from telephone t, client c where c.idclient = t.idclient;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		return $exec->fetchAll();
	}

	public function selectWhereTelephone($idtelephone)
	{
		$requete = "select * from technicien where idtelephone = :idtelephone; ";
		$donnees = array(":idtelephone" => $idtelephone);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetch();

	}
	public function selectLikeTelephones($filtre)
	{
		$requete = "select * from telephne where designation like :filtre or dateAchat like :filtre;";
		$donnees = array(":filtre" => "%" . $filtre . "%");
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetchAll();
	}
	public function deletetelephone($idtelephone)
	{
		$requete = "delete from telephone where idtelephone = :idtelephone ;";
		$donnees = array(":idtelephone" => $idtelephone);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);

	}

	public function updatetelephone($tab)
	{
		$requete = "update telephone set designation =:designation, prixAchat =:prixAchat, etat=:etat, dateAchat=:dateAchat, idclient=:idclient where idtelephone =:idtelephone; ";
		$donnees = array(
			":designation" => $tab["designation"],
			":prixAchat" => $tab["prixAchat"],
			":etat" => $tab["etat"],
			":dateAchat" => $tab["dateAchat"],
			":idclient" => $tab["idclient"],
			":idtelephone" => $tab["idtelephone"]
		);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);


	}

	public function countTelephones()
	{
		$requete = "select count(*) as nb from telephone;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		return $exec->fetch();
	}


	/************gestion User********** */

	public function verifConnexion($email, $mdp)
	{
		$requete = "select * from user where email = :email and mdp=:mdp;";
		$donnees = array(":email" => $email, ":mdp" => $mdp);
		$exec = $this->unPdo->prepare($requete);
		$exec->execute($donnees);
		return $exec->fetch();
	}

/***************interventions*********** */
public function selectAllInterventions()
	{
		$requete = "select t.*, c.nom, c.prenom from telephone t, client c where c.idclient = t.idclient;";
		$exec = $this->unPdo->prepare($requete);
		$exec->execute();
		return $exec->fetchAll();
	}

}
